from django.views import generic
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django_filters.views import FilterView
from .models import Task
from .forms import TaskForm
from .utils import export_tasks_pdf, export_tasks_excel

# Mixin to check role
class RoleRequiredMixin(UserPassesTestMixin):
    roles = []
    def test_func(self):
        return self.request.user.role in self.roles

class DashboardView(LoginRequiredMixin, generic.TemplateView):
    template_name = 'tasks/dashboard.html'
    required_roles = ['manager', 'employee']

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        if self.request.user.role == 'manager':
            ctx['tasks'] = Task.objects.filter(assigned_to__manager=self.request.user)
        else:
            ctx['tasks'] = Task.objects.filter(assigned_to=self.request.user)
        return ctx

class TaskListView(LoginRequiredMixin, RoleRequiredMixin, FilterView):
    model = Task
    template_name = 'tasks/task_list.html'
    filterset_fields = ['assigned_to', 'status', 'created_at']
    roles = ['manager', 'employee']

class TaskCreateView(LoginRequiredMixin, RoleRequiredMixin, generic.CreateView):
    form_class = TaskForm
    template_name = 'tasks/task_form.html'
    roles = ['manager']

    def form_valid(self, form):
        form.instance.created_by = self.request.user
        return super().form_valid(form)

class TaskDetailView(LoginRequiredMixin, RoleRequiredMixin, generic.DetailView):
    model = Task
    template_name = 'tasks/task_detail.html'
    roles = ['manager', 'employee']

class TaskUpdateView(LoginRequiredMixin, RoleRequiredMixin, generic.UpdateView):
    model = Task
    fields = ['status', 'manager_comments']
    template_name = 'tasks/task_form.html'
    roles = ['manager']

# Exports
class TaskPDFView(LoginRequiredMixin, generic.View):
    def get(self, request, *args, **kwargs):
        return export_tasks_pdf(request.user)

class TaskExcelView(LoginRequiredMixin, generic.View):
    def get(self, request, *args, **kwargs):
        return export_tasks_excel(request.user)
