import io
from django.http import HttpResponse
from django.template.loader import render_to_string
from weasyprint import HTML
import xlsxwriter
from .models import Task

def export_tasks_pdf(user):
    tasks = Task.objects.filter(assigned_to=user)
    html = HTML(string=render_to_string('tasks/report.html', {'tasks': tasks, 'user': user}))
    pdf = html.write_pdf()
    return HttpResponse(pdf, content_type='application/pdf')

def export_tasks_excel(user):
    output = io.BytesIO()
    workbook = xlsxwriter.Workbook(output)
    worksheet = workbook.add_worksheet()
    headers = ['Name', 'Status', 'Due Date']
    for col, header in enumerate(headers):
        worksheet.write(0, col, header)
    for row, t in enumerate(Task.objects.filter(assigned_to=user), start=1):
        worksheet.write(row, 0, t.name)
        worksheet.write(row, 1, t.status)
        worksheet.write(row, 2, t.due_date.strftime('%Y-%m-%d'))
    workbook.close()
    output.seek(0)
    response = HttpResponse(output.read(), content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = 'attachment; filename=tasks.xlsx'
    return response
