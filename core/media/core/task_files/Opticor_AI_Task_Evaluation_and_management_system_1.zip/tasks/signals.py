from django.db.models.signals import post_save
from django.dispatch import receiver
from django.core.mail import send_mail
from .models import Task

@receiver(post_save, sender=Task)
def task_notification(sender, instance, created, **kwargs):
    subject = None
    message = None
    if created:
        subject = 'New Task Created'
        message = f"Task '{instance.name}' has been created by {instance.created_by}."
        recipient = instance.assigned_to.email
    elif instance.status == 'submitted':
        subject = 'Task Submitted'
        message = f"Task '{instance.name}' submitted for approval."
        recipient = instance.created_by.email
    else:
        return
    send_mail(subject, message, 'no-reply@opticor.com', [recipient])
