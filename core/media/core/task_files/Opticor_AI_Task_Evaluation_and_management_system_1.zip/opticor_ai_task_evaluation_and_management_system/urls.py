from django.contrib import admin
from django.urls import path, include
from tasks.views import DashboardView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('accounts/', include('django.contrib.auth.urls')),
    path('dashboard/', DashboardView.as_view(), name='dashboard'),
    path('tasks/', include('tasks.urls')),
]
