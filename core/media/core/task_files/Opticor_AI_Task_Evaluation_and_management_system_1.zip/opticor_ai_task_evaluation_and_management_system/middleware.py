from django.shortcuts import redirect
from django.urls import reverse

class RoleRequiredMiddleware:
    """
    Middleware to enforce role-based access control.
    Requires each view to define `required_roles` attribute.
    """
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        return self.get_response(request)

    def process_view(self, request, view_func, view_args, view_kwargs):
        required = getattr(view_func, 'required_roles', None)
        if required:
            if not request.user.is_authenticated:
                return redirect(reverse('login'))
            if request.user.role not in required:
                return redirect(reverse('dashboard'))
        return None
